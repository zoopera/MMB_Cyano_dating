#!/bin/bash

for i in `ls COG*fmt`; do trimal -in $i -out $i.phy -phylip_paml ; done
cat COG*phy > input.phy
