#!/usr/bin/perl
#
my @list = `grep -A2 "Substi" *mlc|grep "[0-9]\$" |cut -d "-" -f2`;
my $sum=0;
foreach my $key (@list)
{
	chomp $key;
	$key =~s/ //g;
	if ($key)
	{
		$sum+=$key;
		$n++;
	}
}

my $avg = $sum/$n;
my $rate = 1/$avg;
print "1 $rate\n";
