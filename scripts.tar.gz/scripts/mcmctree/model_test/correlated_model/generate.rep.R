#!/usr/bin/Rscript

b = mcmc3r::make.beta(n=32, a=10, method="step-stones")
mcmc3r::make.bfctlf(b, ctlf="mcmctree.ctl", betaf="beta.txt")
