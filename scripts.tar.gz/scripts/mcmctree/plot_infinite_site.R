#!/usr/bin/Rscript

library(ggplot2)
data <- read.csv("posterior.plot", header = F, sep = "")

#===Infinite site plot===#
k=(summary(lm(data$V9~data$V2-1))[4])$coefficients[1]
r=(summary(lm(data$V9~data$V2-1))[8])$r.squared[1]
eqn<- as.character(as.expression(substitute(italic(y)==b*italic(x)*","~~italic(R)^2~"="~r2,list(b=format(k,digits = 3),r2=(format(r,digits = 3))))))
pdf("Infinite_site.pdf", width = 5, height = 5)
g<-ggplot(data, aes(x=V2,y=V9))+ geom_smooth(method = lm, formula = y~x-1,se = F,linetype="dashed",color="grey")+geom_point()+theme_bw()+annotate("text", label=eqn, parse=T, x=-Inf, y=Inf, hjust=-0.18, vjust=2)+scale_color_manual(values = c("darkred","black"))+ylab("95% HPD CI width (Gyr)")+xlab("Posterior divergence time (Gya)")
print (g)
dev.off()
