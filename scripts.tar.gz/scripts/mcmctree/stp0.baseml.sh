#!/bin/bash
#Usage: for i in `ls *fmt`;do ./baseml.sh $i gene.pos.contree.root.topo.rough_cali; done

tree="gene.pos.contree.root.topo.rough.calibrate"
for i in `ls *fmt`
do
	cp ./baseml_template.ctl ./baseml_$i
	echo "seqfile = $i" >> baseml_$i
	echo "treefile = $tree" >> baseml_$i
	echo "outfile = $i.mlc" >> baseml_$i
	chmod +x baseml_$i
	
	echo "#!/bin/bash" >$i.sh
	echo "baseml baseml_$i" >> $i.sh
	chmod +x $i.sh
	sbatch -n1 $1.sh
done
