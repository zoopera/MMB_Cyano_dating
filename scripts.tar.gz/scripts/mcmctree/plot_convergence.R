#!/usr/bin/Rscript

library(ggplot2)
data <- read.csv("posterior.plot", header = F, sep = "")

#===Convergence plot===#
k_c=(summary(lm(data$V13~data$V2-1))[4])$coefficients[1]
r_c=(summary(lm(data$V13~data$V2-1))[8])$r.squared[1]
eqn2<- as.character(as.expression(substitute(italic(y)==b*italic(x)*","~~italic(R)^2~"="~r2, list(b=format(k_c,digits = 3),r2=(format(r_c,digits = 3))))))
pdf("Convergence.pdf", width = 5, height = 5)
g<-ggplot(data, aes(x=V13,y=V2))+geom_point()+geom_smooth(method = lm, formula = y~x-1,se = F,linetype="dashed",color="grey")+geom_point()+theme_bw()+annotate("text", label=eqn2, parse=T, x=-Inf, y=Inf, hjust=-0.18, vjust=2)+scale_color_manual(values = c("darkred","black"))+ylab("Posterior mean time (Gya) * Run2")+xlab("Posterior mean time (Gya) * Run1")
print (g)
dev.off()


