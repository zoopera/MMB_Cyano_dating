#!/bin/bash

mcmctree > log
