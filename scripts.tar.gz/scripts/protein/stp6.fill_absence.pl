#!/usr/bin/perl
system "cat *2codon > tmp.all";
my @taxa_raw = `grep ">" tmp.all |cut -d ">" -f2|cut -d "|" -f1|sort|uniq`;
foreach my $key (@taxa_raw)
{
	chomp $key;
	push @taxa, $key;
	$taxa_count{$key}=0;
}
system "rm tmp.all";

system "ls *nucalign.2codon > list.txt";
open FILE, "<", "list.txt";
while(<FILE>)
{
	chomp;
	if(/^(\S+)\.nucalign.2codon$/)
	{
		$fam=$1;
		open IN, "<", "$1.nucalign.2codon";
		open OUT, ">", "$1.nucalign.2codon.fmt";
		%hash=();
		$len=0;
		while(<IN>)
		{
			chomp;
			if(/^>(\S+)\|\S+$/)
			{
				$id=$1;
				$seq=<IN>;
				$len=length $seq;
				chomp $seq;
				$hash{$id}=$seq;
			}
		}
		for $taxon (@taxa)
		{
			if(exists $hash{$taxon})
			{
				$taxa_count{$taxon}++;
				print OUT ">$taxon\n$hash{$taxon}\n";
			}
			else
			{
				$gap='';
				for($x=1; $x<$len; $x++)
				{
					$gap .= '-';
				}
				print OUT ">$taxon\n$gap\n";
			}
		}
		close IN;
		close OUT;
	}
}

close FILE;
close TAXA;
system "rm list.txt";
