#!/usr/bin/perl

opendir DIR,"./";
my @list = readdir DIR;
my @list_grep = grep /nucalign$/,@list;
foreach my $file (@list_grep)
{
	open IN,"<","$file";
	open OUT,">>","$file.2codon";
	while(<IN>)
	{
		chomp;
		if (/^>/)
		{
			print OUT "$_\n";
		}
		else
		{
			my @tmp=split(//,$_);
			for (my $i=0;$i<=$#tmp;$i++)
			{
				$num = $i+1;
				if ($num%3==0)
				{
					next;
				}
				else
				{
					print OUT "$tmp[$i]";
				}
			}
			print OUT "\n";
		}
	}
	close IN;
	close OUT;
}
