#!/usr/bin/perl
open LIST, "<", "../dat/table1.tbl";
system "ls *.cog.fm > list.txt";
open FILE, "<", "list.txt";


%cog;
while(<LIST>)
{
	chomp;
	if(/^(COG\d+)/)
	{
		$cog{$1}="exist";
	}
}

while(<FILE>)
{
	chomp;
	if(/^(\S+)\.cog\.fm$/)
	{
		open COG, "<", "$1.cog.fm";
		open PEP, "<", "$1";

		%seqs=();
		while(<PEP>)
		{
			chomp;
			if(/^>(\S+?)$/)
			{
				$id=$1;
				$seq=<PEP>;
				chomp $seq;
				$seqs{$id}=$seq;
			}
		}

		%evalue=();
		%print=();
		while(<COG>)
		{
			chomp;
			if(/^(\S+),\S+,(COG\d+),\S+,\S+,\S+,(\S+)/)
			{
				if(exists $cog{$2})
				{
					if (exists $evalue{$2})
					{
						if ($evalue{$2}>$3)
						{
							$evalue{$2}=$3;
	                                                $print{$2}=$1;
						}
						else
						{
							next;
						}
					}
					else
					{
						$evalue{$2}=$3;
						$print{$2}=$1;
					}
				}
			}
		}
		foreach my $key (sort keys %cog)
		{
			if (exists $print{$key})
			{
				open OUT,">>","$key.fas";
				print OUT ">$print{$key}\n$seqs{$print{$key}}\n";
				close OUT;
			}
		}
		close COG;
		close PEP;
	}
}

close LIST;
close FILE;
system "rm list.txt";

