#!/usr/bin/perl

open IN,"<","../dat/cddid_all.tbl";
while (<IN>)
{	
	my @tmp = split(/\t/,$_);
	if ($tmp[1]=~/COG/)
	{
		$hash{$tmp[0]}=$tmp[1];
	}
}
close IN;
open IN,"<","../dat/cog_names2003-2014.tab";
while (<IN>)
{
	if ($_ !~ m/^#/)
	{
		my @tmp = split (/\t/,$_);
		$cog{$tmp[0]}=$tmp[1];
	}
}
close IN;

my $dir="./";
opendir DIR,$dir;
my @list = readdir DIR;
my @grep_list = grep /cog$/,@list;
foreach my $input (@grep_list)
{
	open IN,"<",$dir."/".$input;
	open OUT,">",$input.".fm";
	while (<IN>)
	{
		my @tmp = split (/\t/,$_);
		my @gnl = split (/\:/,$tmp[1]);
		if (exists $hash{$gnl[1]})
		{
			$cog_out = $hash{$gnl[1]};
			if (exists $cog{$cog_out})
			{
				print OUT $tmp[0].",".$tmp[1].",".$hash{$gnl[1]}.","."$cog{$cog_out},X,".$tmp[2].",".$tmp[10]."\n";
			}
			else
			{
				print OUT $tmp[0].",".$tmp[1].",".$hash{$gnl[1]}.","."no_cog,X,".$tmp[2].",".$tmp[10]."\n";
			}
		}
	}
	close IN;
	close OUT;
}
closedir DIR;
