#!/bin/bash

phy=($(find $1 -maxdepth 1 -type f -name "*rmgap.phy"))

for input in "${phy[@]}"
do
	sub=$(echo $input | sed 's/.*\///g' | sed 's/rmgap.phy/sh/g')
	out=$(echo $input | sed 's/rmgap.phy/tab/g')
	echo -e "#!/bin/bash -l\n\n" > $sub
	echo -e "time java -jar /share/software/prottest/prottest-3.4.2/prottest-3.4.2.jar -i $input -o $out -JTT -LG -WAG -IG -F -BIC -tc 0.5 -threads 4\n" >> $sub

	chmod +x $sub
	./$sub
#	sbatch -n4 $sub 
done

