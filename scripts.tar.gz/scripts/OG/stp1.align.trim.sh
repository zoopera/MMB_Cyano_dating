#!/bin/bash

for i in `ls *fa`; do sed -i "s/>.*|/>/g" $i ; done
for i in `ls *.fa`; do mafft --auto --thread 8 $i >$i.mafft; done 
for i in `ls *.mafft`; do trimal -in $i -out $i.rmgap.phy -phylip_paml -gappyout; done

