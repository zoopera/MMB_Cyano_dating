#!/bin/bash

pys=($(find $1 -name "*py"))

for py in "${pys[@]}"
do
	sub=$(echo $py|sed 's/.*\///g'|sed 's/py/lsf/g')
	out=$(echo $py|sed 's/.*\///g'|sed 's/py/p4/g')

	echo -e "#!/bin/bash\n" > $sub
	echo -e "time p4 $py >$out" >> $sub
	chmod +x $sub
	./$sub
#	sbatch $sub
done
