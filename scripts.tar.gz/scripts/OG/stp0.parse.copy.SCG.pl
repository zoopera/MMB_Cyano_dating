#!/usr/bin/perl

my $file = "Orthogroups.GeneCount.tsv";#Matrix file

open IN,"<","$file";
while (my $line = <IN>)
{
	chomp $line;
	my @tmp = split(/\t/,$line);
	my $id = shift @tmp;
	my $total = pop @tmp;
	$genome = $#tmp+1;
	my $flag = 0;
	my $count = 0;
	foreach my $key (@tmp)
	{
		if ($key ==0)
		{
			next;
		}
		elsif ($key ==1)
		{
			$count++;
		}
		else
		{
			$flag =1;
		}
	}
	if ($flag==0)
	{
		$single{$id}=$count;
	}
}
close IN;

foreach my $key (sort keys %single)
{
	if ($single{$key} >= $genome-9)
	{
		`cp ../protein_outgroup/OrthoFinder/Results_Nov08/Orthogroup_Sequences/$key.fa .`;
	}
}

opendir DIR,"./";
my @list = readdir DIR;
my @list_grep = grep /.fa$/, @list;
foreach my $input (@list_grep)
{
	my ($id)=$input=~/(\S+?)\.fa/;
	open IN,"<","$input";
	open OUT,">>","$input.out";
	chomp (my @file = <IN>);
	for (my $i=0;$i<=$#file;$i++)
	{
		if ($file[$i]=~/^>\S+\|(\S+)/)
		{
			if (exists $hash{$1})
			{
				next;
			}
			else
			{
				print OUT ">$1\n";
				my $seq = ();
				for (my $j=1;$j<=99;$j++)
				{
					if ($file[$i+$j]=~/^>/)
					{
						last;
					}
					else
					{
						$seq.=$file[$i+$j];
					}
				}
				print OUT "$seq\n";
				$hash{$1}=1;
			}
		}
	}
	close IN;
	close OUT;
	system "rm $input";
	system "mv $input.out $input";
}
