#!/bin/bash
nw_reroot gene.pos.contree "Melainabacteria_bacterium_LMEP_6097" "Melainabacteria_bacterium_SSGW_16" "Melainabacteria_bacterium_WWTP_15" "Melainabacteria_bacterium_WWTP_8" "Sericytochromatia_bacterium_GL2-53_LSPB_72" "Sericytochromatia_bacterium_S15B-MN24_CBMW_12" > gene.pos.contree.root

