#!/bin/bash

/share/home-user/hzhang/software/iqtree-2.0.6-Linux/bin/iqtree2 -mset WAG,LG,JTT -mrate G,G+I -mfreq FU -bb 1000 -nt 16 -wbtl -m MFP -s concat.fas -p gene.pos
