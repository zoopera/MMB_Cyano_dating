#!/bin/bash

for i in `ls *fa`
do
mafft --auto --thread 4 $i >$i.mafft
done
