#!/usr/bin/perl

system "ls *.for_cat > list.txt";
system "cat *cat > tmp";
open FILE, "<", "list.txt";
open OUT, ">", "concat.fas";
open OUT2, ">", "gene.pos";

my $genome_count = `grep ">" tmp |sort|uniq|wc -l`;
system "rm tmp";

@mamm=();
for($x=0; $x<$genome_count; $x++)
{
	$mamm[$x]=[];
}

@genome=();
$start_pos=1;
while(<FILE>)
{
	chomp;
	if(/^(\S+)\.for_cat/)
	{
		$gene=$1;
		open IN, "<", "$1.for_cat";
		$c=0;
		
		while(<IN>)
		{
			chomp;
			if(/^>(\S+)$/)
			{
				push @genome, $1;
				$seq=<IN>;
				chomp $seq;
				push @{$mamm[$c]},$seq;
				$c++;
			}
		}
		$len=length $seq;
		$end_pos=$start_pos+$len-1;
		print OUT2 "Genome, $gene = $start_pos\-$end_pos\n";
		$seq='';
		$start_pos=$end_pos+1;
	}
}

for($x=0; $x<$genome_count; $x++)
{
	$temp=join '',@{$mamm[$x]};
	print OUT ">$genome[$x]\n";
	print OUT "$temp\n";
}

close FILE;
close OUT;
close OUT2;
system "rm list.txt";
