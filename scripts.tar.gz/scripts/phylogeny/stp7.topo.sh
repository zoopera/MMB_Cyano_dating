#!/bin/bash

nw_topology -I  gene.pos.contree.root > gene.pos.contree.root.topo
