#!/bin/bash

orthofinder -t 16 -a 16 -f ./protein
